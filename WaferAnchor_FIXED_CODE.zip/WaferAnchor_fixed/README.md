# WaferAnchor

Synthetic reference-to-search localization demo.

## Google Colab workflow

```bash
!git clone https://github.com/VyshaliEtikala/WaferAnchor.git
!pip install -r WaferAnchor/requirements.txt
!python WaferAnchor/src/generate_dataset.py --architecture DRAM --num_pairs 30 --output_dir WaferAnchor/data/generated --seed 42
!python WaferAnchor/src/evaluate.py --data_dir WaferAnchor/data/generated --results_dir WaferAnchor/results
```

The generated dataset contains 30 reference/search pairs and `metadata.json`
with ground-truth coordinates.

`evaluate.py` prints predicted coordinates, ground truth, and numerical
pixel error, and creates annotated images in `results/visualizations/`.
