#!/usr/bin/env python3
"""Reference-to-search localization for WaferAnchor."""

from __future__ import annotations

import argparse

import cv2
import numpy as np


def _prep(img):
    img = img.astype(np.float32)
    img = cv2.GaussianBlur(img, (3, 3), 0)
    return cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)


def _edge(img):
    g = cv2.GaussianBlur(img, (3, 3), 0)
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    mag = cv2.magnitude(gx, gy)
    return cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)


def detect_center(reference, search):
    """Return predicted (x, y) in search-image coordinates."""
    ref = _prep(reference)
    sea = _prep(search)
    h, w = sea.shape

    # Coarse search at half resolution.
    ref_c = cv2.resize(ref, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    sea_c = cv2.resize(sea, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    ref_ec, sea_ec = _edge(ref_c), _edge(sea_c)

    coarse = []
    for template, image, weight in (
        (ref_c, sea_c, 0.65),
        (ref_ec, sea_ec, 0.35),
    ):
        th, tw = template.shape
        for s in np.linspace(0.88, 1.12, 9):
            nw = int(round(tw * s))
            nh = int(round(th * s))
            if nw < 20 or nh < 20 or nw >= image.shape[1] or nh >= image.shape[0]:
                continue

            t = cv2.resize(template, (nw, nh), interpolation=cv2.INTER_LINEAR)
            r = cv2.matchTemplate(image, t, cv2.TM_CCOEFF_NORMED)
            _, score, _, loc = cv2.minMaxLoc(r)
            coarse.append(
                (
                    weight * float(score),
                    (loc[0] + nw / 2.0) * 2.0,
                    (loc[1] + nh / 2.0) * 2.0,
                )
            )

    if not coarse:
        raise RuntimeError("No valid template-match candidate.")

    coarse.sort(reverse=True)

    candidates = []
    for c in coarse:
        if all(
            (c[1] - q[1]) ** 2 + (c[2] - q[2]) ** 2 > 45 ** 2
            for q in candidates
        ):
            candidates.append(c)
        if len(candidates) >= 8:
            break

    refined = []
    ref_e = _edge(ref)

    for base_score, cx, cy in candidates:
        radius = 90
        x1 = max(0, int(round(cx)) - radius)
        y1 = max(0, int(round(cy)) - radius)
        x2 = min(w, int(round(cx)) + radius)
        y2 = min(h, int(round(cy)) + radius)

        roi = sea[y1:y2, x1:x2]
        roi_e = _edge(roi)

        if roi.shape[0] <= ref.shape[0] or roi.shape[1] <= ref.shape[1]:
            continue

        ri = cv2.matchTemplate(roi, ref, cv2.TM_CCOEFF_NORMED)
        re = cv2.matchTemplate(roi_e, ref_e, cv2.TM_CCOEFF_NORMED)

        _, si, _, li = cv2.minMaxLoc(ri)
        _, se, _, le = cv2.minMaxLoc(re)

        score = 0.65 * float(si) + 0.35 * float(se)

        tw = ref.shape[1]
        th = ref.shape[0]

        # Average the intensity and edge locations for a little robustness.
        px_i = x1 + li[0] + tw / 2
        py_i = y1 + li[1] + th / 2
        px_e = x1 + le[0] + tw / 2
        py_e = y1 + le[1] + th / 2

        px = 0.65 * px_i + 0.35 * px_e
        py = 0.65 * py_i + 0.35 * py_e
        refined.append((score, px, py))

    if not refined:
        return float(candidates[0][1]), float(candidates[0][2])

    refined.sort(key=lambda z: z[0], reverse=True)
    best = refined[0][0]
    eligible = [c for c in refined if c[0] >= best - 0.03]

    cx0, cy0 = w / 2, h / 2
    chosen = min(
        eligible,
        key=lambda c: (c[1] - cx0) ** 2 + (c[2] - cy0) ** 2,
    )
    return float(chosen[1]), float(chosen[2])


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--reference", required=True)
    p.add_argument("--search", required=True)
    args = p.parse_args()

    ref = cv2.imread(args.reference, cv2.IMREAD_GRAYSCALE)
    search = cv2.imread(args.search, cv2.IMREAD_GRAYSCALE)

    if ref is None:
        raise FileNotFoundError(args.reference)
    if search is None:
        raise FileNotFoundError(args.search)

    x, y = detect_center(ref, search)
    print(f"Predicted center: ({x:.2f}, {y:.2f})")


if __name__ == "__main__":
    main()
