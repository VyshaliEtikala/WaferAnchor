#!/usr/bin/env python3
"""Evaluate all generated WaferAnchor pairs and create visual results."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import cv2

from inference import detect_center


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", default="data/generated")
    p.add_argument("--results_dir", default="results")
    args = p.parse_args()

    data_dir = Path(args.data_dir)
    results_dir = Path(args.results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    (results_dir / "visualizations").mkdir(parents=True, exist_ok=True)

    records = json.loads((data_dir / "metadata.json").read_text(encoding="utf-8"))
    rows = []

    for rec in records:
        ref_path = data_dir / rec["ref"]
        search_path = data_dir / rec["search"]

        ref = cv2.imread(str(ref_path), cv2.IMREAD_GRAYSCALE)
        search = cv2.imread(str(search_path), cv2.IMREAD_GRAYSCALE)

        if ref is None or search is None:
            raise FileNotFoundError(f"Could not read pair {rec['id']}")

        px, py = detect_center(ref, search)
        gx = float(rec["center"]["x"])
        gy = float(rec["center"]["y"])
        error = math.hypot(px - gx, py - gy)

        rows.append(
            {
                "id": rec["id"],
                "predicted_x": px,
                "predicted_y": py,
                "ground_truth_x": gx,
                "ground_truth_y": gy,
                "error_pixels": error,
            }
        )

        vis = cv2.cvtColor(search, cv2.COLOR_GRAY2BGR)
        cv2.drawMarker(
            vis, (round(gx), round(gy)), (0, 255, 0),
            cv2.MARKER_CROSS, 35, 3,
        )
        cv2.circle(vis, (round(px), round(py)), 16, (255, 0, 0), 3)
        cv2.line(
            vis, (round(gx), round(gy)),
            (round(px), round(py)), (0, 0, 255), 2,
        )
        cv2.putText(
            vis, f"GT=({gx:.1f},{gy:.1f})",
            (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
            (0, 255, 0), 2,
        )
        cv2.putText(
            vis, f"Pred=({px:.1f},{py:.1f})  Error={error:.2f}px",
            (15, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
            (255, 0, 0), 2,
        )

        out_name = results_dir / "visualizations" / f"result_{rec['id']:05d}.png"
        cv2.imwrite(str(out_name), vis)

    csv_path = results_dir / "evaluation.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    mean_error = sum(r["error_pixels"] for r in rows) / len(rows)
    max_error = max(r["error_pixels"] for r in rows)
    median_error = sorted(r["error_pixels"] for r in rows)[len(rows) // 2]

    summary = {
        "samples": len(rows),
        "mean_error_pixels": mean_error,
        "median_error_pixels": median_error,
        "max_error_pixels": max_error,
    }
    (results_dir / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print(f"Samples: {len(rows)}")
    print(f"Mean error:   {mean_error:.2f} pixels")
    print(f"Median error: {median_error:.2f} pixels")
    print(f"Max error:    {max_error:.2f} pixels")
    print(f"CSV: {csv_path}")
    print(f"Visualizations: {results_dir / 'visualizations'}")


if __name__ == "__main__":
    main()
